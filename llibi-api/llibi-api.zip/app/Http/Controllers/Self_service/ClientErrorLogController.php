<?php

namespace App\Http\Controllers\Self_service;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ClientErrorLogController extends Controller
{
    //
}
